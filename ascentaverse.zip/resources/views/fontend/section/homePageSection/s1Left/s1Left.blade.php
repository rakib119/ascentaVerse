<div class="fluid-one_content-column">
    <div class="fluid-one_column-inner">
                <!-- Sec Title -->
        <div class="sec-title">
            <div class="sec-title_title">Who We Are?</div>
            <h2 class="sec-title_heading">Our <span class='theme_color'>penetration</span> <br> testing  team uses an <br><span class='theme_color'>industry</span> <span class="theme_color"></span> <br></h2>
            <div class="sec-title_text">We provide the full spectrum of IT services and consulting for various industries.</div>
        </div>
        <div class="d-flex">
            <div class="button-box ">
                <a class="btn-style-five theme-btn btn-item" href="http://127.0.0.1:8000/about">
                    <div class="btn-wrap">
                        <span class="text-one">About Us<i class="fa-solid fa-plus"></i></span>
                        <span class="text-two">Our Services<i class="fa-solid fa-plus"></i></span>
                    </div>
                </a>
            </div>
            <div class="button-box" style="margin-left: 15px;">
                <a class="btn-style-two theme-btn btn-item" href="http://127.0.0.1:8000/services">
                    <div class="btn-wrap">
                        <span class="text-one">Our Services<i class="fa-solid fa-plus"></i></span>
                        <span class="text-two">Our Services<i class="fa-solid fa-plus"></i></span>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>
