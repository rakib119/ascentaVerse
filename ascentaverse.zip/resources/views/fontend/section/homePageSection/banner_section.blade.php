<section class="fluid-one">
    <div class="outer-container d-flex">

        @include('fontend.section.homePageSection.s1Left.s1Left')

        @include('fontend.section.homePageSection.s1Right.s1Right')
    </div>
</section>
