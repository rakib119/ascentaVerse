<!DOCTYPE html>
<html>
<head>
    <title>My Dynamic Blade View</title>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($content); ?></p>
</body>
</html><?php /**PATH D:\ascentaverse\resources\views/banner.blade.php ENDPATH**/ ?>