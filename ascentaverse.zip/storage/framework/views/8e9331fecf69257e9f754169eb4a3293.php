
<section class="fluid-one">
    <div class="outer-container d-flex">
        <!-- Content Column -->
        <div class="fluid-one_content-column">
            <div class="fluid-one_column-inner">
                <?php
                    $title = preg_replace('/\*\*(.*?)\*\*/', "<span class='theme_color'>$1</span>", $data->title);
                ?>
                <!-- Sec Title -->
                <div class="sec-title">
                    <div class="sec-title_title"><?php echo e($data->lebel); ?></div>
                    <h2 class="sec-title_heading"><?php echo $title; ?> <span class="theme_color"></span> <br></h2>
                    <div class="sec-title_text"><?php echo e($data->short_description); ?></div>
                </div>
                <div class="d-flex">
                    <div class="button-box ">
                        <a class="btn-style-five theme-btn btn-item" href="<?php echo e($data->link1); ?>">
                            <div class="btn-wrap">
                                <span class="text-one"><?php echo e($data->btn1); ?><i class="fa-solid fa-plus"></i></span>
                                <span class="text-two"><?php echo e($data->btn2); ?><i class="fa-solid fa-plus"></i></span>
                            </div>
                        </a>
                    </div>
                    <div class="button-box" style="margin-left: 15px;">
                        <a class="btn-style-two theme-btn btn-item" href="<?php echo e($data->link2); ?>">
                            <div class="btn-wrap">
                                <span class="text-one"><?php echo e($data->btn2); ?><i class="fa-solid fa-plus"></i></span>
                                <span class="text-two"><?php echo e($data->btn2); ?><i class="fa-solid fa-plus"></i></span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="fluid-one_carousel-column">
            <div class="image-container-wrapper">
                <div class="image-container">
                    <div class="slider-container">
                        <div class="slide" style="background-image: url('<?php echo e(asset('assets/images/resource/fluid-1.jpg')); ?>')"></div>

                        <div class="slide" style="background-image: url('<?php echo e(asset('assets/images/resource/fluid-2.jpg')); ?>')"></div>

                        <div class="slide" style="background-image: url('<?php echo e(asset('assets/images/resource/fluid-3.jpg')); ?>')"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\laravel 11\ascentaverse\resources\views/fontend/section/homePageSection/bannerTemplate.blade.php ENDPATH**/ ?>