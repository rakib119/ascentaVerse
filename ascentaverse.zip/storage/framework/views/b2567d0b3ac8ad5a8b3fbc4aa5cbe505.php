<section class="fluid-one">
    <div class="outer-container d-flex align-items-center">
        <!-- Content Column -->
        <div class="fluid-one_content-column">
            <div class="fluid-one_column-inner">
                <!-- Sec Title -->
                <div class="row border-row">
                    <?php for($i=1; $i<=3; $i++): ?>
                        <div class="service-block_two col-lg-4 col-md-6 col-sm-12">
                            <div class="service-block_two-inner">
                                <div class="service-block_two-image">
                                    <img src="<?php echo e(asset("assets/images/partners/h3-client$i.png")); ?>"
                                        alt="Partner <?php echo e($i); ?>" />
                                </div>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
                <div class="row border-row">
                    <?php for($j=4; $j<=6; $j++): ?>
                        <div class="service-block_two col-lg-4 col-md-6 col-sm-12">
                            <div class="service-block_two-inner">
                                <div class="service-block_two-image">
                                    <img src="<?php echo e(asset("assets/images/partners/h3-client$j.png")); ?>"
                                        alt="Partner <?php echo e($j); ?>" />
                                </div>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        <!-- Content Column -->
        
        <?php echo $__env->make('fontend.section.homePageSection.s3Right.s3Right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>
<?php /**PATH D:\laravel 11\ascentaverse\resources\views/fontend/section/homePageSection/partner_section.blade.php ENDPATH**/ ?>