<!DOCTYPE html>
          <html>
          <head>
              <title>My Static Page</title>
          </head>
          <body>
              <h1>Static Page with Dynamic Content</h1>
              <ul><li>Item 1</li><li>Item 2</li><li>Item 3</li><li>Item 4</li><li>Item 5</li><li>Item 6</li></ul>
          </body>
          </html><?php /**PATH D:\ascentaverse\resources\views/staticpage.blade.php ENDPATH**/ ?>