<?php $__env->startSection('mainContent'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ascentaverse\it-firm\Laravel\ascentaVerse\resources\views/fontend/homePage/index2.blade.php ENDPATH**/ ?>