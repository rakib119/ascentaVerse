<section class="fluid-one">
    <div class="outer-container d-flex">

        <?php echo $__env->make('fontend.section.homePageSection.s1Left.s1Left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('fontend.section.homePageSection.s1Right.s1Right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>
<?php /**PATH D:\laravel 11\ascentaverse\resources\views/fontend/section/homePageSection/banner_section.blade.php ENDPATH**/ ?>