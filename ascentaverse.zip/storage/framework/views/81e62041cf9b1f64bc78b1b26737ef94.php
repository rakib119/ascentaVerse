<div class="fluid-one_content-column">
    <div class="fluid-one_column-inner">
        <div class="sec-title">
            <div class="sec-title_title"><?php echo e($data->lebel); ?></div>
            <?php
                $title = preg_replace('/\*\*(.*?)\*\*/', "<span class='theme_color'>$1</span>", $data->title);
            ?>
            <h2 class="sec-title_heading"><?php echo $title; ?> <br></h2>
            <div class="sec-title_text"><?php echo e($data->short_description); ?></div>
        </div>
    </div>
</div>
<?php /**PATH D:\laravel 11\ascentaverse\resources\views/fontend/section/homePageSection/s3Right/s3RightTemplate.blade.php ENDPATH**/ ?>