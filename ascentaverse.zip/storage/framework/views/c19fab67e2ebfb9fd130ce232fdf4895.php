<div class="fluid-one_carousel-column">
    <div class="image-container-wrapper">
        <div class="image-container">
            <div class="slider-container">
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slide" style="background-image: url('<?php echo e(asset('assets/images/banners/'.$v->image_name)); ?>'"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\laravel 11\ascentaverse\resources\views/fontend/section/homePageSection/s1Right/s1RightTemplate.blade.php ENDPATH**/ ?>