<section class="about-one">
    <div class="auto-container">
        <div class="row clearfix">
            <!-- Content Column -->
            <div class="about-one_content col-lg-6 col-md-12 col-sm-12">
                <div class="about-one_content-inner">
                    <div class="sec-title">
                        <div class="sec-title_title"><?php echo e($data->lebel); ?></div>
                        <?php
                            $title = preg_replace('/\*\*(.*?)\*\*/', "<span>$1</span>", $data->title);
                        ?>
                        <h2 class="sec-title_heading"><?php echo $title; ?></h2>
                        <div class="sec-title_text"><?php echo e($data->short_description); ?></div>
                    </div>

                    <!-- About Info Tabs -->
                    <div class="about-info-tabs">
                        <!-- About Tabs -->
                        <div class="about-tabs tabs-box">

                            <!-- Tab Btns -->
                            <ul class="tab-btns tab-buttons clearfix">
                                <li data-tab="#prod-mission" class="tab-btn active-btn"><?php echo e($data->btn1); ?></li>
                                <li data-tab="#prod-vision" class="tab-btn"><?php echo e($data->btn2); ?></li>
                                <li data-tab="#prod-value" class="tab-btn"><?php echo e($data->btn1); ?></li>
                            </ul>

                            <!-- Tabs Container -->
                            <div class="tabs-content">

                                <!-- Tab / Active Tab -->
                                <div class="tab active-tab" id="prod-mission">
                                    <div class="content">
                                        <div class="text"><?php echo e($data->description1); ?></div>
                                    </div>
                                </div>

                                <!-- Tab -->
                                <div class="tab" id="prod-vision">
                                    <div class="content">
                                        <div class="text"><?php echo e($data->description2); ?></div>
                                    </div>
                                </div>

                                <!-- Tab -->
                                <div class="tab" id="prod-value">
                                    <div class="content">
                                        <div class="text"><?php echo e($data->description3); ?></div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <!-- About One Detail -->
                    <a class="about-one_detail lightbox-video" href="<?php echo e($data->link2); ?>">
                        <?php echo e($data->link1); ?>

                        <span class="play-icon"><span class="fa-solid fa-play fa-fw"></span><i class="ripple"></i></span>
                    </a>

                </div>
            </div>
            <!-- Image Column -->
            <div class="about-one_image-column col-lg-6 col-md-12 col-sm-12">
                <div class="about-one-image-inner">
                    <div class="about-one_color-layer"></div>
                    <div class="about-cicle_layer">
                        <img src="<?php echo e(asset('assets/images/icons/circle-layer.png')); ?>" alt="" />
                    </div>
                    <div class="about-one_image">
                        <img src="<?php echo e(asset('assets/images/about/'.$data->img1)); ?>" alt="" />
                    </div>
                    <div class="about-one_bold-text"><?php echo e($data->lebel); ?></div>
                    <div class="about-one_image-text"><?php echo e($data->img2); ?></div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\laravel 11\ascentaverse\resources\views/fontend/section/homePageSection/s2About/about_section_template.blade.php ENDPATH**/ ?>