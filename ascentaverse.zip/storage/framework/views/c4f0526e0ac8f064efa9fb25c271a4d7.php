<ul class="metismenu list-unstyled" id="side-menu">
    <li class="menu-title">Menu</li>
    
        <li>
            <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
                <i class="dripicons-home"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="fas fa-project-diagram"></i>
                <span>Home Management</span>
            </a>
             <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(route('homeS1Left.index')); ?>"> Home S1 Left </a></li>
                <li><a href="<?php echo e(route('homeS1Right.index')); ?>"> Home S1 Right </a></li>
                <li><a href="<?php echo e(route('homeS2.index')); ?>"> Home S2 (About) </a></li>
                <li><a href="<?php echo e(route('homeS3Left.index')); ?>"> Home S3 Left(Partners) </a></li>
                <li><a href="<?php echo e(route('homeS3Right.index')); ?>"> Home S3 Right(Partners) </a></li>
            </ul>
            
        </li>
        

    
   

</ul>
<?php /**PATH D:\laravel 11\ascentaverse\resources\views/dashboard/layout/menu.blade.php ENDPATH**/ ?>