<?php $__env->startSection('mainContent'); ?>
<!-- Page Title -->
<section class="page-title" style="background-image:url(<?php echo e(asset("assets/images/background/4.jpg")); ?>)">
    <div class="auto-container">
        <h2>Kyc</h2>
        <ul class="bread-crumb clearfix">
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li>Kyc</li>
        </ul>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ascentaverse\it-firm\Laravel\ascentaVerse\resources\views/fontend/mainPages/kyc.blade.php ENDPATH**/ ?>