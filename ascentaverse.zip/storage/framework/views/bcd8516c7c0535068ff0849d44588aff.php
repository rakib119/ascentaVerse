<div class="fluid-one_content-column">
    <div class="fluid-one_column-inner">
        <div class="sec-title">
            <div class="sec-title_title">Our Partners</div>
                        <h2 class="sec-title_heading">Long Time Project, with </br> <span class='theme_color'>Our Best Partner</span> <br></h2>
            <div class="sec-title_text">We’ve been lucky to collaborate with a long list of customers, located in and out of the country. Thanks to them we have grown as professionals</div>
        </div>
    </div>
</div>
<?php /**PATH D:\laravel 11\ascentaverse\resources\views/fontend/section/homePageSection/s3Left/s3Left.blade.php ENDPATH**/ ?>