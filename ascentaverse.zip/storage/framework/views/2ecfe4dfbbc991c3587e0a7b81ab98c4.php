<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQs and Contact Form</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet"> <!-- External CSS file -->
</head>

<body>
    <section class="elementor-section elementor-top-section elementor-element elementor-element-d34a3d6 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default ct-header-fixed-none ct-column-none ct-row-scroll-none ct-row-gradient--none"
        data-id="d34a3d6" data-element_type="section" data-settings='{"stretch_section":"section-stretched"}'>
        <div class="container">
            <div class="row">
                <div class="col-md-6 elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-74508ba ct-column-none col-offset-none col-color-offset-none"
                    data-id="74508ba" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-1ffcd68 elementor-widget elementor-widget-ct_heading"
                            data-id="1ffcd68" data-element_type="widget" data-widget_type="ct_heading.default">
                            <div class="elementor-widget-container">
                                <div id="ct_heading-1ffcd68" class="ct-heading h-align- item-st-default highlight-style1">
                                    <div class="ct-heading--inner">
                                        <div class="item--text-below"></div>
                                        <div class="item--sub-title style-line-right" data-wow-delay="ms">
                                            <span>FAQs</span>
                                        </div>
                                        <h3 class="item--title st-default" data-wow-delay="ms">
                                            <span class="ct-text-inner">Frequently Asked Questions</span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-181ce5d elementor-widget elementor-widget-ct_accordion"
                            data-id="181ce5d" data-element_type="widget" data-widget_type="ct_accordion.default">
                            <div class="elementor-widget-container">
                                <div id="ct_accordion-181ce5d" class="ct-accordion ct-accordion1 style2" data-wow-duration="1.2s">
                                    <div class="ct-accordion-item">
                                        <div class="ct-ac-title" data-target="#510e216ct_accordion-181ce5d">
                                            <a class="ct-ac-title-text">What does having Managed your services provider?
                                                <i class="ct-accordion-icon-plus"></i>
                                            </a>
                                        </div>
                                        <div id="510e216ct_accordion-181ce5d" class="ct-ac-content">
                                            Our purpose is to build solutions that remove the barriers preventing people
                                            from doing their best work, and this is at the heart of how we approach our.
                                        </div>
                                    </div>
                                    <div class="ct-accordion-item">
                                        <div class="ct-ac-title" data-target="#cd58149ct_accordion-181ce5d">
                                            <a class="ct-ac-title-text">What you about say your Business planning?
                                                <i class="ct-accordion-icon-plus"></i>
                                            </a>
                                        </div>
                                        <div id="cd58149ct_accordion-181ce5d" class="ct-ac-content">
                                            We encourage every team member to be a whole person. We have a flexible, high
                                            trust environment that is focused on doing great work.
                                        </div>
                                    </div>
                                    <div class="ct-accordion-item">
                                        <div class="ct-ac-title" data-target="#f368cafct_accordion-181ce5d">
                                            <a class="ct-ac-title-text">You have a unique way of the working in IT?
                                                <i class="ct-accordion-icon-plus"></i>
                                            </a>
                                        </div>
                                        <div id="f368cafct_accordion-181ce5d" class="ct-ac-content">
                                            Our purpose is to build solutions that remove barriers preventing people from
                                            doing their best work, and this is at the heart.
                                        </div>
                                    </div>
                                    <div class="ct-accordion-item">
                                        <div class="ct-ac-title" data-target="#fce1b45ct_accordion-181ce5d">
                                            <a class="ct-ac-title-text">What types of systems do you support?
                                                <i class="ct-accordion-icon-plus"></i>
                                            </a>
                                        </div>
                                        <div id="fce1b45ct_accordion-181ce5d" class="ct-ac-content">
                                            Increase social reach and productivity with our App Directory, a collection
                                            of famous applications like Instagram other web design.
                                        </div>
                                    </div>
                                    <div class="ct-accordion-item active">
                                        <div class="ct-ac-title active" data-target="#85143cect_accordion-181ce5d">
                                            <a class="ct-ac-title-text">Can you provide all IT Management services?
                                                <i class="ct-accordion-icon-plus"></i>
                                            </a>
                                        </div>
                                        <div id="85143cect_accordion-181ce5d" class="ct-ac-content" style="display:block;">
                                            Design studio founded in London and expanded our services, and become a
                                            multinational firm, offering services and solutions.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-5726ced ct-column-none col-offset-none col-color-offset-none"
                    data-id="5726ced" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-e8640b1 elementor-widget elementor-widget-ct_heading"
                            data-id="e8640b1" data-element_type="widget" data-widget_type="ct_heading.default">
                            <div class="elementor-widget-container">
                                <div id="ct_heading-e8640b1" class="ct-heading h-align- item-st-default highlight-style1">
                                    <div class="ct-heading--inner">
                                        <div class="item--text-below"></div>
                                        <div class="item--sub-title style-line-right" data-wow-delay="ms">
                                            <span>Get In Touch</span>
                                        </div>
                                        <h3 class="item--title st-default" data-wow-delay="ms">
                                            <span class="ct-text-inner">Make An Free IT Consultant</span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-element elementor-element-3ab947c elementor-widget elementor-widget-ct_contact_form"
                            data-id="3ab947c" data-element_type="widget" data-widget_type="ct_contact_form.default">
                            <div class="elementor-widget-container">
                                <div class="ct-contact-form ct-contact-form-layout1 style3">
                                    <div class="ct-contact-form">
                                        <div class="wpcf7 no-js" id="wpcf7-f3753-p2394-o1" lang="en-US" dir="ltr">
                                            <div class="screen-reader-response">
                                                <p role="status" aria-live="polite" aria-atomic="true"></p>
                                                <ul></ul>
                                            </div>
                                            <form action="https://demo.casethemes.net/itfirm/home-2/#wpcf7-f3753-p2394-o1"
                                                method="post" class="wpcf7-form init" aria-label="Contact form"
                                                novalidate="novalidate" data-status="init">
                                                <div style="display: none;">
                                                    <input type="hidden" name="_wpcf7" value="3753" />
                                                    <input type="hidden" name="_wpcf7_version" value="5.8.6" />
                                                    <input type="hidden" name="_wpcf7_locale" value="en_US" />
                                                    <input type="hidden" name="_wpcf7_unit_tag"
                                                        value="wpcf7-f3753-p2394-o1" />
                                                    <input type="hidden" name="_wpcf7_container_post" value="2394" />
                                                    <input type="hidden" name="_wpcf7_posted_data_hash" value="" />
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-6 col-md-6 mb-3">
                                                        <p>
                                                            <span class="wpcf7-form-control-wrap" data-name="your-name">
                                                                <input size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control"
                                                                    aria-required="true" aria-invalid="false"
                                                                    placeholder="Name" value="" type="text"
                                                                    name="your-name" />
                                                            </span>
                                                        </p>
                                                    </div>
                                                    <div class="col-lg-6 col-md-6 mb-3">
                                                        <p>
                                                            <span class="wpcf7-form-control-wrap" data-name="your-email">
                                                                <input size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email form-control"
                                                                    aria-required="true" aria-invalid="false"
                                                                    placeholder="Email" value="" type="email"
                                                                    name="your-email" />
                                                            </span>
                                                        </p>
                                                    </div>
                                                    <div class="col-lg-6 col-md-6 mb-3">
                                                        <p>
                                                            <span class="wpcf7-form-control-wrap" data-name="your-phone">
                                                                <input size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel form-control"
                                                                    aria-required="true" aria-invalid="false"
                                                                    placeholder="Phone" value="" type="tel"
                                                                    name="your-phone" />
                                                            </span>
                                                        </p>
                                                    </div>
                                                    <div class="col-lg-6 col-md-6 mb-3">
                                                        <p>
                                                            <span class="wpcf7-form-control-wrap" data-name="your-service">
                                                                <input size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control"
                                                                    aria-required="true" aria-invalid="false"
                                                                    placeholder="Service" value="" type="text"
                                                                    name="your-service" />
                                                            </span>
                                                        </p>
                                                    </div>
                                                    <div class="col-12 mb-3">
                                                        <p>
                                                            <span class="wpcf7-form-control-wrap" data-name="your-message">
                                                                <textarea cols="40" rows="10"
                                                                    class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required form-control"
                                                                    aria-required="true" aria-invalid="false"
                                                                    placeholder="Message" name="your-message"></textarea>
                                                            </span>
                                                        </p>
                                                    </div>
                                                    <div class="col-12">
                                                        <p>
                                                            <input class="wpcf7-form-control has-spinner wpcf7-submit btn btn-primary"
                                                                type="submit" value="Send Message" />
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="wpcf7-response-output" aria-hidden="true"></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- end of elementor-widget-wrap -->
                </div> <!-- end of col-md-6 -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </section>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.2.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH D:\ascentaverse\it-firm\Laravel\ascentaVerse\resources\views/fontend/homePage/index1.blade.php ENDPATH**/ ?>