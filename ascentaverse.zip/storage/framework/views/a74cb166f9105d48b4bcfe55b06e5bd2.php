<div class="fluid-one_carousel-column">
    <div class="image-container-wrapper">
        <div class="image-container">
            <div class="slider-container">
                                    <div class="slide" style="background-image: url('http://127.0.0.1:8000/assets/images/banners/s0uCTljjNbn7q3k.jpg'"></div>
                                    <div class="slide" style="background-image: url('http://127.0.0.1:8000/assets/images/banners/t8caCkyBj9qPtgF.jpg'"></div>
                                    <div class="slide" style="background-image: url('http://127.0.0.1:8000/assets/images/banners/07eZ2Mgm1h4CmzP.jpg'"></div>
                            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\laravel 11\ascentaverse\resources\views/fontend/section/homePageSection/s1Right/s1Right.blade.php ENDPATH**/ ?>