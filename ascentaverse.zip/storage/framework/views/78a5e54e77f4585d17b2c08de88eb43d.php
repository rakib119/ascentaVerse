<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-content">
        <div class="page-title-box">
            <div class="container-fluid">
             <div class="row align-items-center">
                 <div class="col-sm-6">
                     <div class="page-title">
                         <h4>DashBoard</h4>
                         <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">DashBoard</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Home Management</a></li>
                            <li class="breadcrumb-item active">Left Section(1)</li>
                        </ol>
                     </div>
                 </div>
             </div>
            </div>
         </div>
         <div class="container-fluid">
            <div class="page-content-wrapper">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h2 class=" mb-4">Data</h2>
                                    </div>
                                    <div class="float-end d-none d-sm-block">
                                        <form action="<?php echo e(route('homeS1Left.publish')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-warning" type="submit">Publish</button>
                                        </form>
                                    </div>
                                </div>
                                <div class="form py-3">
                                    <?php
                                      $update_id =   $data?->id;
                                      $route = $update_id ? route('homeS1Left.update',$update_id) : route('homeS1Left.store');
                                      $button_name = $update_id ? 'Update' : 'Submit';
                                      $btn_class = $update_id ? 'btn-info' : 'btn-success';
                                    ?>
                                    <?php if(session('error')): ?>
                                        <h4 class="text-danger">Error: <?php echo e(session('error')); ?> ** </h4>
                                    <?php endif; ?>
                                    <form action="<?php echo e($route); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php if($update_id): ?>
                                            <?php echo method_field('put'); ?>
                                        <?php endif; ?>
                                        <input type="hidden" name="section_id" value="1">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label" for="lebel"> Lebel
                                                        <span class="text-danger">*</span></label>
                                                    <input id="lebel" type="text" class="form-control"
                                                        value="<?php echo e($data->lebel ?? old('lebel')); ?>" name="lebel"
                                                        placeholder="Enter lebel" autofocus>
                                                    <?php $__errorArgs = ['lebel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <h6 class="text-danger"> <?php echo e($message); ?></h6>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label" for="title">Title
                                                        <span class="text-danger">*</span></label>
                                                    <input id="title" type="text" class="form-control"
                                                        value="<?php echo e($data->title ?? old('title')); ?>" name="title"
                                                        placeholder="Enter title" >
                                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <h6 class="text-danger"> <?php echo e($message); ?></h6>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="mb-3">
                                                    <label class="form-label" for="project_name">Description <span class="text-danger">*</span></label>
                                                    <input id="short_description" type="text" class="form-control"
                                                        value="<?php echo e($data->short_description ?? old('short_description')); ?>" name="short_description"
                                                        placeholder="Enter short description">

                                                    <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <h6 class="text-danger"> <?php echo e($message); ?></h6>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label" for="btn1">Button 1
                                                        <span class="text-danger">*</span></label>
                                                    <input id="btn1" type="text" class="form-control"
                                                        value="<?php echo e($data->btn1 ?? old('btn1')); ?>" name="btn1"
                                                        placeholder="Enter button 1">
                                                    <?php $__errorArgs = ['btn1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <h6 class="text-danger"> <?php echo e($message); ?></h6>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label" for="link1">Button 1 link
                                                        <span class="text-danger">*</span></label>
                                                    <input id="link1" type="text" class="form-control"
                                                        value="<?php echo e($data->link1 ?? old('link1')); ?>" name="link1"
                                                        placeholder="Enter link 1" >
                                                    <?php $__errorArgs = ['link1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <h6 class="text-danger"> <?php echo e($message); ?></h6>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label" for="btn1">Button 2
                                                        <span class="text-danger">*</span></label>
                                                    <input id="btn2" type="text" class="form-control"
                                                        value="<?php echo e($data->btn2 ?? old('btn2')); ?>" name="btn2"
                                                        placeholder="Enter button 2">
                                                    <?php $__errorArgs = ['btn2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <h6 class="text-danger"> <?php echo e($message); ?></h6>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label" for="link2">Button 2 link
                                                        <span class="text-danger">*</span></label>
                                                    <input id="link2" type="text" class="form-control"
                                                        value="<?php echo e($data->link2 ?? old('link2')); ?>" name="link2"
                                                        placeholder="Enter link 2" >
                                                    <?php $__errorArgs = ['link2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <h6 class="text-danger"> <?php echo e($message); ?></h6>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12 mt-3">
                                                <div class="mb-3">
                                                    <button type="submit" class="btn <?php echo e($btn_class); ?>"><?php echo e($button_name); ?> </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel 11\ascentaverse\resources\views/dashboard/pages/home/section1/left/index.blade.php ENDPATH**/ ?>