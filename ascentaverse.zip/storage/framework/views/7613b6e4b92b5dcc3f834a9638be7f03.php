<?php $__env->startSection('mainContent'); ?>
    <!-- Sidebar Cart Item -->
	<div class="xs-sidebar-group info-group">
		<div class="xs-overlay xs-bg-black"></div>
		<div class="xs-sidebar-widget">
			<div class="sidebar-widget-container">
				<div class="close-button">
					<span class="fa fa-solid fa-power-off fa-fw"></span>
				</div>
				<div class="sidebar-textwidget">

					<!-- Sidebar Info Content -->
					<div class="sidebar-info-contents">
						<div class="content-inner">

							<!-- Title Box -->
							<div class="title-box">
								<h5>Shopping <span>Bag</span></h5>
								<div class="price">$15 from free economy shipping</div>
							</div>

							<!-- Empty Cart Box -->
							<div class="empty-cart-box">
								<!-- No Product -->
								<div class="no-cart">
									<span class="icon fa fa-solid fa-cart-plus fa-fw"></span>
									No products in cart.
								</div>
							</div>

							<!-- Lower Box -->
							<div class="lower-box">
								<h5>Popular <span>Suggestions</span></h5>

								<!-- Post Block -->
								<div class="post-block">
									<div class="inner-box">
										<div class="image">
											<img src="<?php echo e(asset('assets/images/resource/post-thumb-1.jpg')); ?>" alt="" />
										</div>
										<h6><a href="#">Technical Support</a></h6>
										<div class="rating">
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
										</div>
										<div class="price-box">$125</div>
										<a class="theme-btn bag-btn" href="#">add to bag</a>
									</div>
								</div>

								<!-- Post Block -->
								<div class="post-block">
									<div class="inner-box">
										<div class="image">
											<img src="<?php echo e(asset('assets/images/resource/post-thumb-2.jpg')); ?>" alt="" />
										</div>
										<h6><a href="#">Business Planning</a></h6>
										<div class="rating">
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
										</div>
										<div class="price-box">$205</div>
										<a class="theme-btn bag-btn" href="#">add to bag</a>
									</div>
								</div>

								<!-- Post Block -->
								<div class="post-block">
									<div class="inner-box">
										<div class="image">
											<img src="<?php echo e(asset('assets/images/resource/post-thumb-3.jpg')); ?>" alt="" />
										</div>
										<h6><a href="#">Cyber Security</a></h6>
										<div class="rating">
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
											<span class="fa fa-star"></span>
										</div>
										<div class="price-box">$125</div>
										<a class="theme-btn bag-btn" href="#">add to bag</a>
									</div>
								</div>

							</div>

						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<!-- Banner One -->
	<section class="banner-one">
		<div class="bubble-dotted">
            <span class="dotted dotted-1"></span>
            <span class="dotted dotted-2"></span>
            <span class="dotted dotted-3"></span>
            <span class="dotted dotted-4"></span>
            <span class="dotted dotted-5"></span>
            <span class="dotted dotted-6"></span>
            <span class="dotted dotted-7"></span>
            <span class="dotted dotted-8"></span>
            <span class="dotted dotted-9"></span>
            <span class="dotted dotted-10"></span>
        </div>
		<div class="auto-container">
			<div class="banner-one_shadow-layer" style="background-image:url('assets/images/background/pattern-27.png)"></div>
			<div class="banner-one_icons" data-parallax='{"y" : -150}' style="background-image:url('assets/images/icons/banner-icons.png)"></div>
			<div class="banner-one_circles" style="background-image:url('assets/images/background/pattern-28.png)"></div>
			<!-- Content Column -->
			<h1 class="banner-one_heading">learning, working <br> and <span>vacationing</span></h1>
			<!-- Button Box -->
			<div class="banner-one_button">
				<a class="btn-style-five theme-btn btn-item" href="#">
					<div class="btn-wrap">
						<span class="text-one">Contact us for hire</span>
						<span class="text-two">Contact us for hire</span>
					</div>
				</a>
			</div>
			<div class="parallax-scene-1">
				<div class="banner-one_image" data-depth="0.15">
					<img src="<?php echo e(asset('assets/images/resource/banner.png')); ?>" alt="" />
				</div>
			</div>
		</div>
	</section>
	<!-- End Main Slider -->

	<!-- Company One -->
	<section class="company-one">
		<div class="company-one_shadow" style="background-image:url('assets/images/background/pattern-29.png)"></div>
		<div class="auto-container">
			<!-- Sec Title Three -->
			<div class="sec-title_three centered">
				<div class="sec-title_three-big_title">features</div>
				<div class="sec-title_three-title">Awesome features</div>
				<h2 class="sec-title_three-heading">Choose <span>The Best</span> IT <br> Service Company</h2>
				<div class="sec-title_three-text">An IT firm or MSP who keeps your IT running smoothly.</div>
			</div>
			<div class="row clearfix">

				<!-- Company One -->
				<div class="company-one_block col-lg-4 col-md-6 col-sm-12">
					<div class="company-one_block_inner" style="background-image:url('assets/images/background/pattern-30.png)">
						<div class="company-one_block_icon"><img src="<?php echo e(asset('assets/images/icons/service-12.png')); ?>" alt="" /></div>
						<h5 class="company-one_block_heading">Technical Support</h5>
						<a href="service-detail.html" class="theme-btn company-one_block_arrow fa fa-angle-right"></a>
						<div class="company-one_block_overlay" style="background-image:url('assets/images/background/pattern-31.png)">
							<div class="company-one_block_icon"><img src="<?php echo e(asset('assets/images/icons/service-12.png')); ?>" alt="" /></div>
							<h5 class="company-one_block_heading">Technical Support</h5>
							<div class="company-one_block_text">Our customers get solutions and the business opportunities instead.</div>
							<a href="service-detail.html" class="theme-btn company-one_block_arrow fa fa-angle-right"></a>
						</div>
					</div>
				</div>

				<!-- Company One -->
				<div class="company-one_block active col-lg-4 col-md-6 col-sm-12">
					<div class="company-one_block_inner" style="background-image:url('assets/images/background/pattern-30.png)">
						<div class="company-one_block_icon"><img src="<?php echo e(asset('assets/images/icons/service-13.png')); ?>" alt="" /></div>
						<h5 class="company-one_block_heading">Business Planning</h5>
						<a href="service-detail.html" class="theme-btn company-one_block_arrow fa fa-angle-right"></a>
						<div class="company-one_block_overlay" style="background-image:url('assets/images/background/pattern-31.png)">
							<div class="company-one_block_icon"><img src="<?php echo e(asset('assets/images/icons/service-13.png')); ?>" alt="" /></div>
							<h5 class="company-one_block_heading">Business Planning</h5>
							<div class="company-one_block_text">Our customers get solutions and the business opportunities instead.</div>
							<a href="service-detail.html" class="theme-btn company-one_block_arrow fa fa-angle-right"></a>
						</div>
					</div>
				</div>

				<!-- Company One -->
				<div class="company-one_block col-lg-4 col-md-6 col-sm-12">
					<div class="company-one_block_inner" style="background-image:url('assets/images/background/pattern-30.png)">
						<div class="company-one_block_icon"><img src="<?php echo e(asset('assets/images/icons/service-14.png')); ?>" alt="" /></div>
						<h5 class="company-one_block_heading">Cyber Security</h5>
						<a href="service-detail.html" class="theme-btn company-one_block_arrow fa fa-angle-right"></a>
						<div class="company-one_block_overlay" style="background-image:url('assets/images/background/pattern-31.png)">
							<div class="company-one_block_icon"><img src="<?php echo e(asset('assets/images/icons/service-14.png')); ?>" alt="" /></div>
							<h5 class="company-one_block_heading">Cyber Security</h5>
							<div class="company-one_block_text">Our customers get solutions and the business opportunities instead.</div>
							<a href="service-detail.html" class="theme-btn company-one_block_arrow fa fa-angle-right"></a>
						</div>
					</div>
				</div>

			</div>

			<div class="company-one_lower-text">Conditions are applied for individual service <a href="#">Terms & Conditions</a></div>

		</div>
	</section>
	<!-- End Company One -->

	<!-- Company One -->
	<section class="company-two">
		<div class="bubble-dotted">
            <span class="dotted dotted-1"></span>
            <span class="dotted dotted-2"></span>
            <span class="dotted dotted-3"></span>
            <span class="dotted dotted-4"></span>
            <span class="dotted dotted-5"></span>
            <span class="dotted dotted-6"></span>
            <span class="dotted dotted-7"></span>
            <span class="dotted dotted-8"></span>
            <span class="dotted dotted-9"></span>
            <span class="dotted dotted-10"></span>
        </div>
		<div class="auto-container">
			<div class="row clearfix">
				<!-- Image Column -->
				<div class="company-two_image-column col-lg-6 col-md-12 col-sm-12">
					<div class="company-two_image-inner">
						<div class="sec-title_three">
							<div class="sec-title_three-big_title">Features</div>
							<div class="sec-title_three-title">Why You choose our company?</div>
							<h2 class="sec-title_three-heading">Choose The Best IT <br> Service Company</h2>
							<div class="sec-title_three-text">By optimizing your body’s innate capacity to heal, many chronic diseases can be mitigated.</div>
						</div>
						<ul class="compant-two_list">
							<li><span>1</span>We’ve created a paradigm to enhance this healing potential by taking all aspects.</li>
							<li><span>2</span>Our courses are made with experts, pack a ton of value and are binge-able.</li>
							<li><span>3</span>This approach to health care addresses the root causes of disease and views the body as one integrated system.</li>
						</ul>
						<a href="#" class="theme-btn btn-style-six">our services <span class="fa-solid fa-plus fa-fw"></span></a>
					</div>
				</div>
				<!-- Content Column -->
				<div class="company-two_content-column col-lg-6 col-md-12 col-sm-12">
					<div class="company-two_content-inner wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="company-two_image">
							<img src="<?php echo e(asset('assets/images/resource/company.png')); ?>" alt="" />
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Company One -->

	<!-- Company One -->
	<section class="about-three">
		<div class="about-three_shadow" style="background-image:url('assets/images/background/pattern-32.png)"></div>
		<div class="auto-container">
			<div class="row clearfix">

				<!-- Content Column -->
				<div class="about-three_content-column col-lg-6 col-md-12 col-sm-12">
					<div class="about-three_content-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="about-three_image">
							<img src="<?php echo e(asset('assets/images/resource/about-3.png')); ?>" alt="" />
						</div>
					</div>
				</div>

				<!-- Image Column -->
				<div class="about-three_image-column col-lg-6 col-md-12 col-sm-12">
					<div class="about-three_image-inner">
						<div class="sec-title_three">
							<div class="sec-title_three-big_title">about us</div>
							<div class="sec-title_three-title">About our IT Company</div>
							<h2 class="sec-title_three-heading">Choose The Best IT <br> Service Company</h2>
							<div class="sec-title_three-text">By optimizing your body’s innate capacity to heal, many chronic diseases can be mitigated.</div>
						</div>

						<!-- Skills -->
						<div class="default-skills">

							<!-- Skill Item -->
							<div class="default-skill-item">
								<div class="default-skill-bar">
									<div class="default-bar-inner">
										<div class="default-bar progress-line" data-width="90">
											<div class="default-skill-percentage"></div>
										</div>
									</div>
								</div>
								<div class="default-count-box count-box"><span class="count-text" data-speed="2000" data-stop="90">0</span>%</div>
								<div class="default-skill-title">UI/UX Design</div>
							</div>

							<!-- Skill Item -->
							<div class="default-skill-item">
								<div class="default-skill-bar">
									<div class="default-bar-inner">
										<div class="default-bar progress-line" data-width="95">
											<div class="default-skill-percentage"></div>
										</div>
									</div>
								</div>
								<div class="default-count-box count-box"><span class="count-text" data-speed="2000" data-stop="95">0</span>%</div>
								<div class="default-skill-title">SEO Marketing</div>
							</div>

							<!-- Skill Item -->
							<div class="default-skill-item">
								<div class="default-skill-bar">
									<div class="default-bar-inner">
										<div class="default-bar progress-line" data-width="70">
											<div class="default-skill-percentage"></div>
										</div>
									</div>
								</div>
								<div class="default-count-box count-box"><span class="count-text" data-speed="2000" data-stop="70">0</span>%</div>
								<div class="default-skill-title">Web Development</div>
							</div>

						</div>

						<!-- About One Detail -->
						<a class="about-three_play lightbox-video" href="https://www.youtube.com/watch?v=kxPCFljwJws">
							<span class="fa-solid fa-play fa-fw"><i class="ripple"></i></span>
							watch play
						</a>

					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- End Company One -->

	<!-- Counter Three -->
	<section class="counter-three">
		<div class="auto-container">
			<div class="counter-three_inner-container">
				<div class="counter-three_pattern-one" style="background-image:url('assets/images/background/pattern-33.png)"></div>
				<div class="counter-three_pattern-two" style="background-image:url('assets/images/background/pattern-34.png)"></div>

				<div class="row clearfix">

					<!-- Counter Column -->
					<div class="counter-three_block col-lg-4 col-md-6 col-sm-6">
						<div class="counter-three_block-inner">
							<span class="counter-three_counter-icon"><img src="<?php echo e(asset('assets/images/icons/counter-1.png')); ?>" alt="" /></span>
							<div class="counter-three_counter"><span class="odometer" data-count="122"></span>+</div>
						</div>
						<div class="counter-three_text">For over a decade, we've been <br> partnering ever.</div>
					</div>

					<!-- Counter Column -->
					<div class="counter-three_block col-lg-4 col-md-6 col-sm-6">
						<div class="counter-three_block-inner">
							<span class="counter-three_counter-icon"><img src="<?php echo e(asset('assets/images/icons/counter-2.png')); ?>" alt="" /></span>
							<div class="counter-three_counter"><span class="odometer" data-count="36"></span>+</div>
						</div>
						<div class="counter-three_text">For over a decade, we've been <br> partnering ever.</div>
					</div>

					<!-- Counter Column -->
					<div class="counter-three_block col-lg-4 col-md-6 col-sm-6">
						<div class="counter-three_block-inner">
							<span class="counter-three_counter-icon"><img src="<?php echo e(asset('assets/images/icons/counter-3.png')); ?>" alt="" /></span>
							<div class="counter-three_counter"><span class="odometer" data-count="99"></span>%</div>
						</div>
						<div class="counter-three_text">For over a decade, we've been <br> partnering ever.</div>
					</div>

				</div>

			</div>
		</div>
	</section>
	<!-- End Counter Three -->

	<!-- Steps One -->
	<section class="steps-one">
		<div class="steps-one_shadow" style="background-image:url('assets/images/background/pattern-35.png)"></div>
		<div class="steps-one_shadow-two" style="background-image:url('assets/images/background/pattern-36.png)"></div>
		<div class="auto-container">
			<!-- Sec Title Three -->
			<div class="sec-title_three centered">
				<div class="sec-title_three-big_title">steps</div>
				<div class="sec-title_three-title">how it works</div>
				<h2 class="sec-title_three-heading">We have some <span>easy steps</span> <br> to process</h2>
				<div class="sec-title_three-text">An IT firm or MSP who keeps your IT running smoothly.</div>
			</div>
			<div class="steps-one_blocks-outer">

				<!-- Step Block One -->
				<div class="step-block_one">
					<div class="step-block_one-inner wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="row clearfix">
							<!-- Step Block One -->
							<div class="step-block_one-content col-lg-6 col-md-12 col-sm-12">
								<div class="step-block_one-content-inner">
									<h3 class="step-block_one-title">Send us Message</h3>
									<div class="step-block_one-text">Once you’ve completed a short registration process, you can choose your first goal from TelMD’s five areas of life: Body, Energy, Mind, Mood and Spirit.</div>
									<div class="step-block_one-arrow fa-solid fa-arrow-right fa-fw"></div>
									<a href="#" class="theme-btn btn-style-six">our services <span class="fa-solid fa-plus fa-fw"></span></a>
								</div>
							</div>
							<!-- Step Block One -->
							<div class="step-block_one-number-column col-lg-6 col-md-12 col-sm-12">
								<div class="step-block_one-number-inner">
									<div class="d-flex step-block_one-number-content">
										<div class="step-block_one-number">01</div>
										<span class="step-one_icon"><img src="<?php echo e(asset('assets/images/icons/step-1.png')); ?>" alt="" /></span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Step Block One -->
				<div class="step-block_one">
					<div class="step-block_one-inner wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="row clearfix">
							<!-- Step Block One -->
							<div class="step-block_one-content col-lg-6 col-md-12 col-sm-12">
								<div class="step-block_one-content-inner">
									<h3 class="step-block_one-title">Discuss With Us</h3>
									<div class="step-block_one-text">Once you’ve completed a short registration process, you can choose your first goal from TelMD’s five areas of life: Body, Energy, Mind, Mood and Spirit.</div>
									<div class="step-block_one-arrow fa-solid fa-arrow-right fa-fw"></div>
									<a href="#" class="theme-btn btn-style-six">Open a ticket <span class="fa-solid fa-plus fa-fw"></span></a>
								</div>
							</div>
							<!-- Step Block One -->
							<div class="step-block_one-number-column col-lg-6 col-md-12 col-sm-12">
								<div class="step-block_one-number-inner">
									<div class="d-flex step-block_one-number-content">
										<div class="step-block_one-number">02</div>
										<span class="step-one_icon"><img src="<?php echo e(asset('assets/images/icons/step-2.png')); ?>" alt="" /></span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Step Block One -->
				<div class="step-block_one">
					<div class="step-block_one-inner wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="row clearfix">
							<!-- Step Block One -->
							<div class="step-block_one-content col-lg-6 col-md-12 col-sm-12">
								<div class="step-block_one-content-inner">
									<h3 class="step-block_one-title">Make a Payment!</h3>
									<div class="step-block_one-text">Once you’ve completed a short registration process, you can choose your first goal from TelMD’s five areas of life: Body, Energy, Mind, Mood and Spirit.</div>
									<div class="step-block_one-arrow fa-solid fa-arrow-right fa-fw"></div>
									<a href="#" class="theme-btn btn-style-six">contact us <span class="fa-solid fa-plus fa-fw"></span></a>
								</div>
							</div>
							<!-- Step Block One -->
							<div class="step-block_one-number-column col-lg-6 col-md-12 col-sm-12">
								<div class="step-block_one-number-inner">
									<div class="d-flex step-block_one-number-content">
										<div class="step-block_one-number">03</div>
										<span class="step-one_icon"><img src="<?php echo e(asset('assets/images/icons/step-3.png')); ?>" alt="" /></span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- End Steps One -->

	<!-- Services Two -->
	<section class="services-two">
		<div class="bubble-dotted">
            <span class="dotted dotted-1"></span>
            <span class="dotted dotted-2"></span>
            <span class="dotted dotted-3"></span>
            <span class="dotted dotted-4"></span>
            <span class="dotted dotted-5"></span>
            <span class="dotted dotted-6"></span>
            <span class="dotted dotted-7"></span>
            <span class="dotted dotted-8"></span>
            <span class="dotted dotted-9"></span>
            <span class="dotted dotted-10"></span>
        </div>
		<div class="auto-container">
			<!-- Sec Title Three -->
			<div class="sec-title_three centered">
				<div class="sec-title_three-big_title">Services</div>
				<div class="sec-title_three-title">Awesome Services</div>
				<h2 class="sec-title_three-heading">Our Awesome <span>services</span> to <br> give you success.</h2>
				<div class="sec-title_three-text">An IT firm or MSP who keeps your IT running smoothly.</div>
			</div>
			<div class="services-carousel owl-carousel owl-theme">

				<!-- Service Block Four -->
				<div class="service-block_four">
					<div class="service-block_four-inner">
						<span class="service-block_four-icon"><img src="<?php echo e(asset('assets/images/icons/service-15.png')); ?>" alt="" /></span>
						<h5 class="service-block_four-title">Data Entry Services</h5>
						<div class="service-block_four-text">These are our businesses, that we own the majority. These are our core stake in.</div>
						<ul class="service-block_four-list">
							<li>Image Data include</li>
							<li>Office Data include</li>
							<li>Surver form</li>
							<li>Online Data</li>
						</ul>
						<div class="service-block_four-button">
							<a href="#" class="theme-btn more-detail">More Details <span class="arrow fa-solid fa-arrow-right fa-fw"></span></a>
						</div>
					</div>
				</div>

				<!-- Service Block Four -->
				<div class="service-block_four">
					<div class="service-block_four-inner">
						<span class="service-block_four-icon"><img src="<?php echo e(asset('assets/images/icons/service-16.png')); ?>" alt="" /></span>
						<h5 class="service-block_four-title">Design & Development</h5>
						<div class="service-block_four-text">These are our businesses, that we own the majority. These are our core stake in.</div>
						<ul class="service-block_four-list">
							<li>Image Data include</li>
							<li>Office Data include</li>
							<li>Surver form</li>
							<li>Online Data</li>
						</ul>
						<div class="service-block_four-button">
							<a href="#" class="theme-btn more-detail">More Details <span class="arrow fa-solid fa-arrow-right fa-fw"></span></a>
						</div>
					</div>
				</div>

				<!-- Service Block Four -->
				<div class="service-block_four">
					<div class="service-block_four-inner">
						<span class="service-block_four-icon"><img src="<?php echo e(asset('assets/images/icons/service-17.png')); ?>" alt="" /></span>
						<h5 class="service-block_four-title">Marketing Services</h5>
						<div class="service-block_four-text">These are our businesses, that we own the majority. These are our core stake in.</div>
						<ul class="service-block_four-list">
							<li>Image Data include</li>
							<li>Office Data include</li>
							<li>Surver form</li>
							<li>Online Data</li>
						</ul>
						<div class="service-block_four-button">
							<a href="#" class="theme-btn more-detail">More Details <span class="arrow fa-solid fa-arrow-right fa-fw"></span></a>
						</div>
					</div>
				</div>

				<!-- Service Block Four -->
				<div class="service-block_four">
					<div class="service-block_four-inner">
						<span class="service-block_four-icon"><img src="<?php echo e(asset('assets/images/icons/service-15.png')); ?>" alt="" /></span>
						<h5 class="service-block_four-title">Data Entry Services</h5>
						<div class="service-block_four-text">These are our businesses, that we own the majority. These are our core stake in.</div>
						<ul class="service-block_four-list">
							<li>Image Data include</li>
							<li>Office Data include</li>
							<li>Surver form</li>
							<li>Online Data</li>
						</ul>
						<div class="service-block_four-button">
							<a href="#" class="theme-btn more-detail">More Details <span class="arrow fa-solid fa-arrow-right fa-fw"></span></a>
						</div>
					</div>
				</div>

				<!-- Service Block Four -->
				<div class="service-block_four">
					<div class="service-block_four-inner">
						<span class="service-block_four-icon"><img src="<?php echo e(asset('assets/images/icons/service-16.png')); ?>" alt="" /></span>
						<h5 class="service-block_four-title">Design & Development</h5>
						<div class="service-block_four-text">These are our businesses, that we own the majority. These are our core stake in.</div>
						<ul class="service-block_four-list">
							<li>Image Data include</li>
							<li>Office Data include</li>
							<li>Surver form</li>
							<li>Online Data</li>
						</ul>
						<div class="service-block_four-button">
							<a href="#" class="theme-btn more-detail">More Details <span class="arrow fa-solid fa-arrow-right fa-fw"></span></a>
						</div>
					</div>
				</div>

				<!-- Service Block Four -->
				<div class="service-block_four">
					<div class="service-block_four-inner">
						<span class="service-block_four-icon"><img src="<?php echo e(asset('assets/images/icons/service-17.png')); ?>" alt="" /></span>
						<h5 class="service-block_four-title">Marketing Services</h5>
						<div class="service-block_four-text">These are our businesses, that we own the majority. These are our core stake in.</div>
						<ul class="service-block_four-list">
							<li>Image Data include</li>
							<li>Office Data include</li>
							<li>Surver form</li>
							<li>Online Data</li>
						</ul>
						<div class="service-block_four-button">
							<a href="#" class="theme-btn more-detail">More Details <span class="arrow fa-solid fa-arrow-right fa-fw"></span></a>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- End Services Two -->

	<!-- Testimonial Section -->
	<section class="testimonial-section-two" style="background-image: url('assets/images/background/map.png)">
		<div class="testimonial-section-two_shadow" style="background-image:url('assets/images/background/pattern-35.png)"></div>
		<div class="testimonial-section-two_shadow-two" style="background-image:url('assets/images/background/pattern-35.png)"></div>
		<div class="auto-container">
			<div class="side-image">
				<img src="<?php echo e(asset('assets/images/resource/testimonial.png')); ?>" alt="" />
			</div>
			<div class="inner-container">

				<!-- Sec Title -->
				<div class="sec-title_three">
					<div class="sec-title_three-big_title">reviews</div>
					<div class="sec-title_three-title">Client’s Testimonials</div>
					<h2 class="sec-title_three-heading">Our awesome clients review <br> for inspiration.</h2>
					<div class="sec-title_three-text">By optimizing your body’s innate capacity to heal, many chronic <br> diseases can be mitigated.</div>
				</div>

				<div class="carousel-outer">
				<div class="single-item-carousel owl-carousel owl-theme">

					<!-- Testimonial Block -->
					<div class="testimonial-block">
						<div class="inner-box">
							<div class="rating">
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
							</div>
							<div class="text">“I To helped the client achieve their goal of calling the attention of mobile network operators. The expert team was also able to develop an app with commendable UI/UX. The client appreciates their flexibility in terms.”</div>
						</div>
						<div class="author-box">
							<div class="box-inner">
								<span class="author-image">
									<img src="<?php echo e(asset('assets/images/resource/author-1.jpg')); ?>" alt="" />
								</span>
								<h5>Arnold Burner</h5>
								<div class="designation">Senior Developer</div>
							</div>
						</div>
					</div>

					<!-- Testimonial Block -->
					<div class="testimonial-block">
						<div class="inner-box">
							<div class="rating">
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
							</div>
							<div class="text">“I To helped the client achieve their goal of calling the attention of mobile network operators. The expert team was also able to develop an app with commendable UI/UX. The client appreciates their flexibility in terms.”</div>
						</div>
						<div class="author-box">
							<div class="box-inner">
								<span class="author-image">
									<img src="<?php echo e(asset('assets/images/resource/author-1.jpg')); ?>" alt="" />
								</span>
								<h5>Arnold Burner</h5>
								<div class="designation">Senior Developer</div>
							</div>
						</div>
					</div>

					<!-- Testimonial Block -->
					<div class="testimonial-block">
						<div class="inner-box">
							<div class="rating">
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
							</div>
							<div class="text">“I To helped the client achieve their goal of calling the attention of mobile network operators. The expert team was also able to develop an app with commendable UI/UX. The client appreciates their flexibility in terms.”</div>
						</div>
						<div class="author-box">
							<div class="box-inner">
								<span class="author-image">
									<img src="<?php echo e(asset('assets/images/resource/author-1.jpg')); ?>" alt="" />
								</span>
								<h5>Arnold Burner</h5>
								<div class="designation">Senior Developer</div>
							</div>
						</div>
					</div>

				</div>
				</div>

			</div>
		</div>
	</section>
	<!-- End Testimonial Section -->

	<!-- Clients Two -->
	<section class="clients-two wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
		<div class="auto-container">
			<div class="clients-two_inner-container" style="background-image: url('assets/images/background/pattern-37.png)">
				<h2 class="clients-two_title">Our Trusted <span>Partners</span></h2>

				<!-- Sponsors Carousel -->
				<ul class="sponsors-carousel owl-carousel owl-theme">
					<li class="slide-item"><figure class="client-one_image-box-two"><a href="#"><img src="<?php echo e(asset('assets/images/clients/9.png')); ?>" alt=""></a></figure></li>
					<li class="slide-item"><figure class="client-one_image-box-two"><a href="#"><img src="<?php echo e(asset('assets/images/clients/10.png')); ?>" alt=""></a></figure></li>
					<li class="slide-item"><figure class="client-one_image-box-two"><a href="#"><img src="<?php echo e(asset('assets/images/clients/11.png')); ?>" alt=""></a></figure></li>
					<li class="slide-item"><figure class="client-one_image-box-two"><a href="#"><img src="<?php echo e(asset('assets/images/clients/12.png')); ?>" alt=""></a></figure></li>
					<li class="slide-item"><figure class="client-one_image-box-two"><a href="#"><img src="<?php echo e(asset('assets/images/clients/13.png')); ?>" alt=""></a></figure></li>
					<li class="slide-item"><figure class="client-one_image-box-two"><a href="#"><img src="<?php echo e(asset('assets/images/clients/14.png')); ?>" alt=""></a></figure></li>
					<li class="slide-item"><figure class="client-one_image-box-two"><a href="#"><img src="<?php echo e(asset('assets/images/clients/9.png')); ?>" alt=""></a></figure></li>
					<li class="slide-item"><figure class="client-one_image-box-two"><a href="#"><img src="<?php echo e(asset('assets/images/clients/10.png')); ?>" alt=""></a></figure></li>
					<li class="slide-item"><figure class="client-one_image-box-two"><a href="#"><img src="<?php echo e(asset('assets/images/clients/11.png')); ?>" alt=""></a></figure></li>
					<li class="slide-item"><figure class="client-one_image-box-two"><a href="#"><img src="<?php echo e(asset('assets/images/clients/12.png')); ?>" alt=""></a></figure></li>
				</ul>

			</div>
		</div>
	</section>
	<!-- End Clients Two -->

	<!-- CTA One -->
	<section class="cta-one">
		<div class="auto-container">
			<div class="d-flex justify-content-between align-items-center flex-wrap">
				<div class="left-box">
					<h3 class="cta-one_heading">Looking for the Best IT Business Solutions?</h3>
					<div class="cta-one_text">As a app web crawler expert, We will help to organize.</div>
				</div>
				<div class="right-box">
					<a class="cta-one_btn theme-btn" href="contact.html">get a quote</a>
				</div>
			</div>
		</div>
	</section>
	<!-- End CTA One -->

	<!-- Search Popup -->
	<div class="search-popup">
		<div class="color-layer"></div>
		<button class="close-search"><span class="fa-solid fa-power-off fa-fw"></span></button>
		<form method="post" action="https://html.themexriver.com/it-firm/blog.html">
			<div class="form-group">
				<input type="search" name="search-field" value="" placeholder="Search Here" required="">
				<button class="fa-solid fa-paper-plane fa-fw" type="submit"></button>
			</div>
		</form>
	</div>
	<!-- End Search Popup -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ascentaverse\it-firm\Laravel\ascentaVerse\resources\views/fontend/homePage/index3.blade.php ENDPATH**/ ?>